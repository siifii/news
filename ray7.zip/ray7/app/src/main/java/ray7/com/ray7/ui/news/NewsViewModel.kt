package ray7.com.ray7.ui.news

import android.arch.lifecycle.ViewModel

class NewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
