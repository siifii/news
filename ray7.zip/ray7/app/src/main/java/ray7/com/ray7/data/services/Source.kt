package ray7.com.ray7.data.services

import com.google.gson.annotations.SerializedName

class Source (
        @SerializedName("name") var newsName: String? = null
)


