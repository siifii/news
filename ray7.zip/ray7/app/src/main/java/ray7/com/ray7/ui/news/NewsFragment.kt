package ray7.com.ray7.ui.news

import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import org.jetbrains.anko.toast
import ray7.com.ray7.R
import ray7.com.ray7.data.services.NewsService
import ray7.com.ray7.data.services.RetrofitWebService
import ray7.com.ray7.data.services.responses.GetNewsResponse
import ray7.com.ray7.utils.Utils
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NewsFragment : Fragment() {

    private val TAG = this::class.java.simpleName

    companion object {
        fun newInstance() = NewsFragment()
    }

    private lateinit var viewModel: NewsViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        getNewsServices()

        return inflater.inflate(R.layout.news_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(NewsViewModel::class.java)
    }

    fun getNewsServices() {
        RetrofitWebService.getService().getNews().enqueue(object : Callback<GetNewsResponse> {
            override fun onFailure(call: Call<GetNewsResponse>, t: Throwable) {
                Log.e(TAG, if (null != t.message) t.message else t.toString())
                Utils.errorSnackbar(context, if (Utils.isNotConnected(t))
                    R.string.internet_error
                else
                    R.string.unable_to_get_new
                ) { i -> getNewsServices() }
            }

            override fun onResponse(call: Call<GetNewsResponse>, response: Response<GetNewsResponse>) {
                context!!.toast("Done")
                val r = response.body()

                if (null == r) {
                    onFailure(call, Throwable("Empty Response"))
                    return
                }
                if (r.status == "ok")
            }
        })
    }
}
