package ray7.com.ray7.ui

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import ray7.com.ray7.data.services.RetrofitWebService
import javax.inject.Inject

open class BaseActivity : AppCompatActivity() {

    @Inject
    lateinit var retrofitWebService: RetrofitWebService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        MyApplication.graph.inject(this)
    }
}
